-- =========================================================
-- BD: Clinica Odontologica (MySQL/MariaDB) - phpMyAdmin
-- =========================================================

CREATE DATABASE IF NOT EXISTS clinica_odontologica
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_spanish_ci;

USE clinica_odontologica;

-- ----------------------------
-- 1) Seguridad: Roles y Usuarios
-- ----------------------------
CREATE TABLE roles (
  id_rol INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(30) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE usuarios (
  id_usuario INT AUTO_INCREMENT PRIMARY KEY,
  id_rol INT NOT NULL,
  usuario VARCHAR(50) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  nombres VARCHAR(80) NOT NULL,
  apellidos VARCHAR(80) NOT NULL,
  email VARCHAR(120) NULL,
  telefono VARCHAR(30) NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_usuarios_roles
    FOREIGN KEY (id_rol) REFERENCES roles(id_rol)
    ON UPDATE CASCADE
    ON DELETE RESTRICT
) ENGINE=InnoDB;

-- Roles base
INSERT INTO roles (nombre) VALUES ('ADMIN'), ('RECEPCIONISTA'), ('DOCTOR');

-- ----------------------------
-- 2) Personas: Pacientes y Odontologos
-- ----------------------------
CREATE TABLE pacientes (
  id_paciente INT AUTO_INCREMENT PRIMARY KEY,
  ci VARCHAR(30) NOT NULL UNIQUE,
  nombres VARCHAR(80) NOT NULL,
  apellido_paterno VARCHAR(80) NOT NULL,
  apellido_materno VARCHAR(80) NULL,
  fecha_nacimiento DATE NULL,
  sexo VARCHAR(15) NULL,
  direccion VARCHAR(150) NULL,
  telefono VARCHAR(30) NULL,
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE odontologos (
  id_odontologo INT AUTO_INCREMENT PRIMARY KEY,
  id_usuario INT NOT NULL UNIQUE, -- el odontólogo inicia sesión como usuario
  matricula VARCHAR(50) NOT NULL UNIQUE,
  especialidad VARCHAR(80) NULL,
  CONSTRAINT fk_odontologos_usuarios
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
    ON UPDATE CASCADE
    ON DELETE RESTRICT
) ENGINE=InnoDB;

-- ----------------------------
-- 3) Agenda: Citas
-- ----------------------------
CREATE TABLE citas (
  id_cita INT AUTO_INCREMENT PRIMARY KEY,
  id_paciente INT NOT NULL,
  id_odontologo INT NOT NULL,
  fecha_hora_inicio DATETIME NOT NULL,
  fecha_hora_fin DATETIME NULL,
  estado ENUM('PROGRAMADA','CANCELADA','ATENDIDA','NO_ASISTIO') NOT NULL DEFAULT 'PROGRAMADA',
  motivo VARCHAR(200) NULL,
  creada_por INT NULL, -- usuario que registró la cita (recepción/admin)
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_citas_pacientes
    FOREIGN KEY (id_paciente) REFERENCES pacientes(id_paciente)
    ON UPDATE CASCADE
    ON DELETE RESTRICT,
  CONSTRAINT fk_citas_odontologos
    FOREIGN KEY (id_odontologo) REFERENCES odontologos(id_odontologo)
    ON UPDATE CASCADE
    ON DELETE RESTRICT,
  CONSTRAINT fk_citas_creada_por
    FOREIGN KEY (creada_por) REFERENCES usuarios(id_usuario)
    ON UPDATE CASCADE
    ON DELETE SET NULL
) ENGINE=InnoDB;

-- Evita (en gran parte) duplicar citas con el mismo inicio para el mismo odontólogo
CREATE UNIQUE INDEX ux_citas_doctor_inicio
  ON citas (id_odontologo, fecha_hora_inicio);

-- ----------------------------
-- 4) Servicios y Atención (Historial)
-- ----------------------------
CREATE TABLE servicios (
  id_servicio INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(120) NOT NULL UNIQUE,
  precio DECIMAL(10,2) NOT NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE atenciones (
  id_atencion INT AUTO_INCREMENT PRIMARY KEY,
  id_cita INT NOT NULL UNIQUE, -- una cita atendida genera como máximo una atención
  fecha_atencion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  diagnostico TEXT NULL,
  observaciones TEXT NULL,
  CONSTRAINT fk_atenciones_citas
    FOREIGN KEY (id_cita) REFERENCES citas(id_cita)
    ON UPDATE CASCADE
    ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE detalle_atencion (
  id_detalle INT AUTO_INCREMENT PRIMARY KEY,
  id_atencion INT NOT NULL,
  id_servicio INT NOT NULL,
  cantidad INT NOT NULL DEFAULT 1,
  precio_unitario DECIMAL(10,2) NOT NULL,
  subtotal DECIMAL(10,2) NOT NULL,
  CONSTRAINT fk_detalle_atencion_atenciones
    FOREIGN KEY (id_atencion) REFERENCES atenciones(id_atencion)
    ON UPDATE CASCADE
    ON DELETE CASCADE,
  CONSTRAINT fk_detalle_atencion_servicios
    FOREIGN KEY (id_servicio) REFERENCES servicios(id_servicio)
    ON UPDATE CASCADE
    ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE INDEX ix_detalle_atencion_id_atencion
  ON detalle_atencion (id_atencion);

-- ----------------------------
-- 5) Pagos y Recibos
-- ----------------------------
CREATE TABLE pagos (
  id_pago INT AUTO_INCREMENT PRIMARY KEY,
  id_atencion INT NOT NULL,
  fecha_pago DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  monto DECIMAL(10,2) NOT NULL,
  metodo ENUM('EFECTIVO','TARJETA','TRANSFERENCIA','CREDITO') NOT NULL,
  estado ENUM('PAGADO','PENDIENTE') NOT NULL DEFAULT 'PAGADO',
  registrado_por INT NULL, -- usuario que registró el pago (recepción/admin)
  CONSTRAINT fk_pagos_atenciones
    FOREIGN KEY (id_atencion) REFERENCES atenciones(id_atencion)
    ON UPDATE CASCADE
    ON DELETE RESTRICT,
  CONSTRAINT fk_pagos_registrado_por
    FOREIGN KEY (registrado_por) REFERENCES usuarios(id_usuario)
    ON UPDATE CASCADE
    ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE recibos (
  id_recibo INT AUTO_INCREMENT PRIMARY KEY,
  id_pago INT NOT NULL UNIQUE,
  numero_recibo VARCHAR(50) NOT NULL UNIQUE,
  fecha_recibo DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  total DECIMAL(10,2) NOT NULL,
  CONSTRAINT fk_recibos_pagos
    FOREIGN KEY (id_pago) REFERENCES pagos(id_pago)
    ON UPDATE CASCADE
    ON DELETE RESTRICT
) ENGINE=InnoDB;

-- ----------------------------
-- 6) Vistas útiles (opcional)
-- ----------------------------
-- Vista: agenda con nombres
CREATE OR REPLACE VIEW vw_agenda AS
SELECT
  c.id_cita,
  c.fecha_hora_inicio,
  c.fecha_hora_fin,
  c.estado,
  CONCAT(p.nombres,' ',p.apellido_paterno,' ',IFNULL(p.apellido_materno,'')) AS paciente,
  p.ci AS ci_paciente,
  CONCAT(u.nombres,' ',u.apellidos) AS odontologo,
  o.matricula,
  c.motivo
FROM citas c
JOIN pacientes p ON p.id_paciente = c.id_paciente
JOIN odontologos o ON o.id_odontologo = c.id_odontologo
JOIN usuarios u ON u.id_usuario = o.id_usuario;

-- Vista: detalle de atención con totales
CREATE OR REPLACE VIEW vw_atencion_total AS
SELECT
  a.id_atencion,
  a.fecha_atencion,
  a.id_cita,
  SUM(d.subtotal) AS total_servicios
FROM atenciones a
LEFT JOIN detalle_atencion d ON d.id_atencion = a.id_atencion
GROUP BY a.id_atencion, a.fecha_atencion, a.id_cita;