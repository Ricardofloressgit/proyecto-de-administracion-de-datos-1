<?php session_start(); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Consultorio Dental</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f0f0f0;
        }
        .card {
            margin: 20px;
            padding: 20px;
            border: none;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <?php require_once __DIR__ . '/sidebar.php'; ?>
    <div class="dashboard-main">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h1 class="text-center mt-5">Bienvenido al Dashboard</h1>
            <div class="text-end">
                <span class="badge bg-secondary">Usuario: <?php echo $_SESSION['NombreUsuario']; ?> (<?php echo $_SESSION['rol']; ?>)</span>
                <a href="../panel/Login.php" class="btn btn-sm btn-danger ms-2">Cerrar sesión</a>
            </div>
        </div>
        <div class="row">
            <?php
            try {
                $pdo = new PDO( 'mysql:host=localhost;dbname=clinica_odontologica;charset=utf8mb4', 'Ricardo', 'Ricardo', [ PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC ] );
            } catch (PDOException $e) {
                die('Error de conexión: ' . $e->getMessage());
            }

            $fechaActual = date("Y-m-d");

            // Obtiene el total de citas programadas para hoy
            $query = "SELECT COUNT(*) AS totalCitas FROM citas WHERE DATE(fecha_hora_inicio) = :fechaActual";
            $stmt = $pdo->prepare($query);
            $stmt->bindParam(':fechaActual', $fechaActual);
            $stmt->execute();
            $totalCitasHoy = $stmt->fetch()['totalCitas'];

            // Obtiene el total de pacientes atendidos hoy
            $query = "SELECT COUNT(*) AS totalPacientes FROM atenciones WHERE DATE(fecha_atencion) = :fechaActual";
            $stmt = $pdo->prepare($query);
            $stmt->bindParam(':fechaActual', $fechaActual);
            $stmt->execute();
            $totalPacientesHoy = $stmt->fetch()['totalPacientes'];

            // Obtiene el total de ingresos del día
            $query = "SELECT SUM(monto) AS totalIngresos FROM pagos WHERE DATE(fecha_pago) = :fechaActual";
            $stmt = $pdo->prepare($query);
            $stmt->bindParam(':fechaActual', $fechaActual);
            $stmt->execute();
            $totalIngresosHoy = $stmt->fetch()['totalIngresos'];
            ?>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5>Citas de hoy</h5>
                        <p class="display-4"><?php echo $totalCitasHoy; ?></p>
                        <p class="text-muted">Citas programadas para hoy</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5>Pacientes atendidos</h5>
                        <p class="display-4"><?php echo $totalPacientesHoy; ?></p>
                        <p class="text-muted">Pacientes atendidos hoy</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5>Ingresos del día</h5>
                        <p class="display-4">$<?php echo $totalIngresosHoy; ?></p>
                        <p class="text-muted">Ingresos totales del día</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <h5>Calendario de citas</h5>
                        <?php include_once '../citas/calen.php'; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/locales/es.js"></script>
</body>
</html>
